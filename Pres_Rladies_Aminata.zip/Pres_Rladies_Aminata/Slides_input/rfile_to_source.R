##file that my presentation will source and make plot


rm(list=ls())
#install.packages("readxl")
library(readxl)
#install.packages("ggplot2")
library(ggplot2)
#install.packages("data.table")
library(data.table)
library(knitr) #for kable
library(xtable)

dataOlympics <- read_excel("Z:/Shiny/R_ladies/meetup18/winer_olympic_medals.xlsx")

#kable(head(dataOlympics))

#put some (char) vars into categorical 
dataOlympics[,c(2:7)] <- lapply(dataOlympics[,c(2:7)], function(x)  factor(x))
#rename vars for rpogramming ease
names(dataOlympics) <- c("year", "sport", "event", "country", "gender", "medal_rank", "medal", "name_ath_team", "age_athlete")

#let's create a continuous var for the number of medals by country and year
count_medal <- function (x) (sum(!is.na(x)))

data_dt <- data.table(dataOlympics)
nmedals <-data_dt[,lapply(.SD, count_medal),by=c("country","year"),.SDcols=7]
names(nmedals) <- c("country", "year", "nbmedals.year")
#verif
#with(dataOlympics, table(country, year))

dataO<- merge( dataOlympics, nmedals, by=c("country", "year"))

tab_outc <- function(x){
  cbind(Freq=table(x), Cum=cumsum(table(x)), Percent.=round((prop.table(table(x))*100),2), Cum_perc=cumsum(round((prop.table(table(x))*100),2)))
}


dataO_uniq <- dataO[!duplicated(dataO$country),]

#barplot(table(dataO_uniq $nbmedals.year), xlab = "Number of Medals won by one country for a year", col=rainbow);
#tab_medals <- tab_outc(dataO_uniq $nbmedals.year)
#xtable(tab_medals)

